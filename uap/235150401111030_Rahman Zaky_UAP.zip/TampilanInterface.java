/*Rahman Zaky
 * 235150401111030
 * UAP
 */

package uap;

public interface TampilanInterface {
    void tampilanAksi();
}